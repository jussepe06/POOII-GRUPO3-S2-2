# POOII · Semana 02 · SOLID (Refactor + JUnit)

Refactor de un sistema de gestión de empleados aplicando **SOLID** en Java. Se reemplaza el `if/else` por **polimorfismo**, se separa **dominio** de **infraestructura**, y se aplican **DIP/ISP** con inyección de dependencias. Incluye **pruebas JUnit 5** y `pom.xml` para correr con **Maven**.

## Estructura
```
.
├─ README.md
├─ pom.xml
└─ src
   ├─ main
   │  └─ java
   │     ├─ Empleado.java
   │     ├─ Gerente.java
   │     ├─ Desarrollador.java
   │     ├─ Practicante.java
   │     ├─ EmpleadoRepository.java
   │     ├─ EmpleadoRepositoryDB.java
   │     ├─ Reporteador.java
   │     ├─ ReporteadorConsola.java
   │     ├─ SistemaGestionEmpleados.java
   │     └─ Main.java
   └─ test
      └─ java
         └─ EmpleadoTest.java
```

## Uso rápido

### Con Maven
```bash
mvn -q -DskipTests=true package
mvn -q exec:java -Dexec.mainClass=Main
mvn -q test
```

### Solo Java (sin Maven)
```bash
cd src/main/java
javac *.java
java Main
```

> Evita **espacios** en nombres de archivo. Usa el botón **Run** del `main` propio de Java (no Code Runner).

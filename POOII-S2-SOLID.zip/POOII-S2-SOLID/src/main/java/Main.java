public class Main {
    public static void main(String[] args) {
        EmpleadoRepository repo = new EmpleadoRepositoryDB();
        Reporteador reporteador = new ReporteadorConsola();
        SistemaGestionEmpleados sistema = new SistemaGestionEmpleados(repo, reporteador);

        Empleado gerente = new Gerente("Juan", 5000);
        Empleado desarrollador = new Desarrollador("Ana", 3000);
        Empleado practicante = new Practicante("Luis", 1000);

        sistema.procesarEmpleado(gerente);
        sistema.procesarEmpleado(desarrollador);
        sistema.procesarEmpleado(practicante);
    }
}

interface Reporteador {
    void generar(Empleado empleado, double pago);
}

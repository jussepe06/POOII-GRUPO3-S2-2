class SistemaGestionEmpleados {
    private final EmpleadoRepository repo;
    private final Reporteador reporteador;

    public SistemaGestionEmpleados(EmpleadoRepository repo, Reporteador reporteador) {
        this.repo = repo;
        this.reporteador = reporteador;
    }

    public void procesarEmpleado(Empleado empleado) {
        double pago = empleado.calcularPago();
        System.out.println("Pago calculado: " + pago);
        repo.guardar(empleado);             // DIP: depende de abstracciones
        reporteador.generar(empleado, pago);
    }
}

class ReporteadorConsola implements Reporteador {
    @Override
    public void generar(Empleado empleado, double pago) {
        System.out.println("Generando reporte: " + empleado.getNombre() + " - Pago: " + pago);
    }
}

interface EmpleadoRepository {
    void guardar(Empleado empleado);
}

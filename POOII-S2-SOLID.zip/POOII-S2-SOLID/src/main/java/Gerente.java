class Gerente extends Empleado {
    public Gerente(String nombre, double salarioBase) {
        super(nombre, salarioBase);
    }
    @Override
    public double calcularPago() {
        return getSalarioBase() + 1000.0; // Bono para gerentes
    }
}

abstract class Empleado {
    private final String nombre;
    private final double salarioBase;

    protected Empleado(String nombre, double salarioBase) {
        this.nombre = nombre;
        this.salarioBase = salarioBase;
    }

    public String getNombre() { return nombre; }
    public double getSalarioBase() { return salarioBase; }

    public abstract double calcularPago(); // Polimorfismo (OCP)
}

class EmpleadoRepositoryDB implements EmpleadoRepository {
    @Override
    public void guardar(Empleado empleado) {
        // En un sistema real: ORM/JDBC, transacciones, etc.
        System.out.println("Guardando empleado " + empleado.getNombre() + " en la base de datos...");
    }
}

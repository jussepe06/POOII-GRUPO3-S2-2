import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

/**
 * Pruebas unitarias para validar:
 *  - Reglas de pago por subtipo
 *  - Polimorfismo (LSP)
 *  - DIP (uso de interfaces con inyección de dependencias)
 *  - OCP (agregar un nuevo rol sin tocar el core)
 */
public class EmpleadoTest {

    // ====== Reglas de pago por subtipo ======

    @Test
    void pagoGerenteIncluyeBono() {
        Empleado g = new Gerente("Juan", 5000);
        assertEquals(6000.0, g.calcularPago(), 1e-6);
    }

    @Test
    void pagoDesarrolladorEsIgualABase() {
        Empleado d = new Desarrollador("Ana", 3000);
        assertEquals(3000.0, d.calcularPago(), 1e-6);
    }

    @Test
    void pagoPracticanteEsLaMitad() {
        Empleado p = new Practicante("Luis", 1000);
        assertEquals(500.0, p.calcularPago(), 1e-6);
    }

    // ====== LSP / Polimorfismo ======

    @Test
    void listaPolimorficaSumaPagosCorrectamente() {
        List<Empleado> todos = Arrays.asList(
            new Gerente("G", 1000),       // 1000 + 1000 = 2000
            new Desarrollador("D", 1000), // 1000
            new Practicante("P", 1000)    // 500
        );
        double total = todos.stream().mapToDouble(Empleado::calcularPago).sum();
        assertEquals(3500.0, total, 1e-6);
    }

    // ====== DIP: orquestación por interfaces ======

    static class FakeRepo implements EmpleadoRepository {
        boolean guardado = false;
        Empleado ultimo;

        @Override
        public void guardar(Empleado empleado) {
            guardado = true;
            ultimo = empleado;
        }
    }

    static class FakeReporteador implements Reporteador {
        boolean generado = false;
        Empleado ultimo;
        double ultimoPago;

        @Override
        public void generar(Empleado empleado, double pago) {
            generado = true;
            ultimo = empleado;
            ultimoPago = pago;
        }
    }

    @Test
    void sistemaGestionUsaRepoYReporteadorInyectados() {
        FakeRepo repo = new FakeRepo();
        FakeReporteador rep = new FakeReporteador();
        SistemaGestionEmpleados sistema = new SistemaGestionEmpleados(repo, rep);

        Empleado dev = new Desarrollador("Ana", 3000);
        sistema.procesarEmpleado(dev);

        assertTrue(repo.guardado, "Debe llamar a repo.guardar()");
        assertTrue(rep.generado, "Debe llamar a reporteador.generar()");
        assertEquals(dev, repo.ultimo);
        assertEquals(dev, rep.ultimo);
        assertEquals(3000.0, rep.ultimoPago, 1e-6);
    }

    // ====== OCP: nuevo rol sin tocar el core ======

    static class Consultor extends Empleado {
        public Consultor(String nombre, double salarioBase) {
            super(nombre, salarioBase);
        }
        @Override
        public double calcularPago() {
            return getSalarioBase() * 1.2; // 20% adicional
        }
    }

    @Test
    void ocpNuevoTipoConsultor() {
        Empleado c = new Consultor("Sofía", 4000);
        assertEquals(4800.0, c.calcularPago(), 1e-6);
    }
}
